﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Speech.Recognition;
using System.Diagnostics;
namespace file_input
{
    class Program
    {
        static bool completed;
        static Stopwatch stopwatch = new Stopwatch();
        static void Main(string[] args)
        {
            //Initialize a in-process speech recognition engine
            using(SpeechRecognitionEngine recognizer = new SpeechRecognitionEngine()){
                //creating and loading new grammar
                //Grammar dictation = new DictationGrammar();
                Choices choiceList = new Choices();
                choiceList.Add(new string[] { "eleven","at" ,"your", "one" ,"clock", "and" ,"four" ,"miles" ,"north", "bound","is" ,"a", "triple" ,"seven" ,"heavy","load" });
                GrammarBuilder builder = new GrammarBuilder();
                builder.Append(choiceList);
                Grammar dictation = new Grammar(new GrammarBuilder(builder, 0, 40));
                //recognize max of 40 and min of 0 from grammar
                dictation.Name = "Dictation Grammar";

                recognizer.LoadGrammar(dictation);

                //configuring input to the recognizer
                Console.WriteLine("Enter file name:");
                string file_name = Console.ReadLine();
                //Change this if a file open error occurs
                string file_path = "C:\\Users\\ASUS\\Desktop\\AerX\\Speech Corpus\\" + file_name + ".wav";
                stopwatch.Start();
                recognizer.SetInputToWaveFile(file_path);
                

                //Attaching event handlers for the results of the recognition
                recognizer.SpeechRecognized += new EventHandler<SpeechRecognizedEventArgs>(recognizer_SpeechRecognized);

                recognizer.RecognizeCompleted += new EventHandler<RecognizeCompletedEventArgs>(recognizer_RecognizeCompleted);

                //Perform recognition on the entire file
                Console.WriteLine("Starting asynchronous recognition...");
                completed = false;
                
                recognizer.RecognizeAsync();
                //Keeping console window open.
                while(!completed){
                    Console.ReadLine();
                }
                Console.WriteLine("Done.");
              }
            Console.WriteLine();
            Console.WriteLine("Press any key to exit..");
            Console.ReadKey();
        }

        //Handling the Speech recognized event
        static void recognizer_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
            if(e.Result != null && e.Result.Text != null)
            {

                stopwatch.Stop();
                Console.WriteLine("Time Elapsed: {0}", stopwatch.Elapsed);
                Console.WriteLine("  Recognized text = {0}",e.Result.Text);
                //Writing recognized text to file
                System.IO.StreamWriter file = new System.IO.StreamWriter("C:\\Users\\ASUS\\Desktop\\AerX\\Speech Corpus\\winSAPI_output.txt");
                file.WriteLine(e.Result.Text);
                file.Close();
            }
            else
            {
                Console.WriteLine("Recognized text not available.");

            }
        }

        //Handling the RecognizeCompleted event

        static void recognizer_RecognizeCompleted(object sender,RecognizeCompletedEventArgs e)
        {
            if (e.Error!= null)
            {
                Console.WriteLine("  Error Encountered, {0}: {1}", e.Error.GetType().Name, e.Error.Message);

            }
            if(e.Cancelled)
            {
                Console.WriteLine("  Operation Cancelled.");

            }

            if(e.InputStreamEnded)
            {
                Console.WriteLine("  End of stream encountered.");
            }
            completed = true;
        }





















   



   }
}
    

